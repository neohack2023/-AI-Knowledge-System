# AIOS Tier 1 Control Envelopes — Slice 1

Status: Candidate implementation package  
Scope: global-working-memory  
Mode: READ_ONLY / SIMULATION  
Runtime state: SCHEMA_FROZEN / FIXTURE_SPECIFIED / RUNTIME_NOT_IMPLEMENTED

## Contents

### SCHEMAS
- context-expansion-decision-record.v0.1.schema.json
- decision-coverage-state.v0.1.schema.json
- memory-correction-tombstone.v0.1.schema.json
- workflow-replay-compatibility-envelope.v0.1.schema.json
- validation-verdict-link.v0.1.schema.json

### FIXTURES
- positive-fixtures.v0.1.json
- negative-fixtures.v0.1.json
- fixture-manifest.v0.1.json
- fixture-validation-results.v0.1.json
- semantic-validator-rules.v0.1.json

## Validation result

- Positive fixtures: 5 / 5 structural and semantic pass
- Negative fixtures: 14 / 14 expected-code match
- Fixture digest: 3c169fb76c9a4aebadbb64775528cdf6dbcf40ca7ea6430a3929d67a168a93d3

## Boundary

This package freezes candidate schemas and fixtures only. It does not deploy runtime handlers,
intercept retrieval, suppress live memory, replay live executions, mutate telemetry, change GitHub,
or transfer authority.
